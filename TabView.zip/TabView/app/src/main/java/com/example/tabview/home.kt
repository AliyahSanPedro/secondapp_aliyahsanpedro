package com.example.tabview

import android.os.Bundle
import android.view.Gravity
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageButton
import android.widget.PopupWindow
import androidx.core.content.ContextCompat

class home : Fragment() {

    private lateinit var smoothie1: ImageButton
    private lateinit var smoothie1pop: PopupWindow

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_home, container, false)

        smoothie1 = view.findViewById(R.id.Button1)

        smoothie1.setOnClickListener {
            showSmoothie1Popup(inflater)
            smoothie1pop.showAtLocation(view, Gravity.CENTER, 0, 0)
        }
        return view
    }

    private fun showSmoothie1Popup(inflater: LayoutInflater) {
        val popupView = inflater.inflate(R.layout.smoothie_popup1, null)
        smoothie1pop = PopupWindow(popupView, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        smoothie1pop.setBackgroundDrawable(ContextCompat.getDrawable(requireContext(), R.drawable.popupbg))
        smoothie1pop.isOutsideTouchable = true
        smoothie1pop.isFocusable = true

        val closeButton = popupView.findViewById<Button>(R.id.closeButton1)
        closeButton.setOnClickListener {
            smoothie1pop.dismiss()
        }
    }
}
