package com.example.tabview

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator

class MainActivity : AppCompatActivity() {

    private lateinit var nameSign: EditText
    private lateinit var passwordSign: EditText
    private lateinit var loginButton: Button
    private lateinit var clearButton: Button
    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        nameSign = findViewById(R.id.nameSign)
        passwordSign = findViewById(R.id.passwordSign)
        loginButton = findViewById(R.id.signInButton)
        clearButton = findViewById(R.id.clearButton)

        sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

        loginButton.setOnClickListener{
            val inputText = nameSign.text.toString()
            val inputText1 = passwordSign.text.toString()
            val editor = sharedPreferences.edit()
            editor.putString("text", inputText)
            editor.putString("text2", inputText1)
            editor.apply()
            val intent = Intent(this, TabViewPage::class.java)
            startActivity(intent)
        }

        clearButton.setOnClickListener{
            nameSign.text.clear()
            passwordSign.text.clear()
        }
    }
}
